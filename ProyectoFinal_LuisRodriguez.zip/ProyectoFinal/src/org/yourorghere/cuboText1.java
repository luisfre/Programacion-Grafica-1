/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;
import java.io.File;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.io.IOException;


/**
 *
 * @author Luis Rodriguez
 */
public class cuboText1 {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz;
   
    int tipo;
    float r,g,b;
    
    

    public cuboText1(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz,float r, float g, float b) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.r = r;
        this.g = g;
        this.b = b;
        
        
    }

    public void display(){
         
          gl.glPushMatrix(); 
        gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof); 
            
         gl.glColor3f(r/2, g/2, b/2); 
          gl.glBegin(gl.GL_QUADS);                                
                
                gl.glTexCoord2f(1, 1);                
                gl.glVertex3f(0, 0, 0);     
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0.2f, 0f, 0);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, 0);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(0f, .2f, 0);                                                                                                                                                                                                                                    
            gl.glEnd();  
            
         
         
          
          
          
          
            gl.glColor3f(r, g, b);
                    
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0, 0);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(.2f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f,0f);                                
            gl.glEnd();
           
             gl.glColor3f(r/2, g/2, b/2);      
            
            gl.glBegin(gl.GL_QUADS);                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0, -.2f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(0f, .2f,-.2f);                
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
            gl.glEnd();
           
            gl.glColor3f(r/2, g/2, b/2); 
            gl.glBegin(gl.GL_QUADS);                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.0f, 0, 0f);                               
                                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(0f, .2f,0f);                
                                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(0f, .2f, -.2f);                                                
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, 0f, -.2f);
            gl.glEnd();
            
            gl.glColor3f(r/2, g/2, b/2);
       
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0f, 0f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(.2f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(0f, 0f,-.2f);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.0f, 0, 0f);                                                
            gl.glEnd();
         
             gl.glColor3f(r, g, b);
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f, 0f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, .2f, -.2f);
                                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.0f, .2f, 0f);                                
                
            gl.glEnd();
             
         gl.glPopMatrix();
        
        
    }
    
    
     
            
            
   
    


    
    
}
