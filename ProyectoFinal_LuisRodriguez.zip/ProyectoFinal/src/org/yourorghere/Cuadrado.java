/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author Mamayo
 */
public class Cuadrado {
    GL gl;
    float ancho,alto;
    float r,g,b;

    
    public Cuadrado (GL gl,float ancho, float alto, float r, float g, float b){
       this.gl=gl;

        this.ancho=ancho;
        this.alto=alto;
        this.r=r;
        this.g=g;
        this.b=b;
    }
    public void drawCuadr(float PX,float PY,float PZ){
        gl.glPushMatrix();
        gl.glTranslatef(PX, PY, PZ);
        gl.glColor3f(this.r, this.g, this.b);
        gl.glBegin(GL.GL_QUADS);
        gl.glVertex2f(-(ancho/2), 0);
        gl.glVertex2f((ancho/2),0);
        gl.glVertex2f((ancho/2),alto);
        gl.glVertex2f(-(ancho/2), alto);
        gl.glEnd();
        gl.glPopMatrix();
    }
}
