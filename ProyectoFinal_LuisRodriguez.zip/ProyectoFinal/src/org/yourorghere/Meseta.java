/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Meseta {
    
    GL gl;
    
    float ancho,alto,profundidad;
    
    float x,y,z;
    float rx,ry,rz;
    cuboText p1;
    

    public Meseta(GL gl, float x, float y, float z, float ancho, float alto, float profundidad ,float rx, float ry, float rz) {
        this.gl = gl;
       this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        
    }

   
    
    
     public void display(){
         gl.glPushMatrix();
        
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
        
        
           
         
            
       
         
          p1= new cuboText(gl,-10f,1f,1f,20,8,20,0,0,0,3);
         p1.display(); 
         
         p1= new cuboText(gl,-10.5f,1f,1f,2.5f,9,20,0,0,0,5);
         p1.display(); 
         p1= new cuboText(gl,-6f,1f,1f,2.5f,9,20,0,0,0,5);
         p1.display(); 
         p1= new cuboText(gl,-5.5f,1f,1.5f,2.5f,9,25,0,90,0,5);
         p1.display(); 
         p1= new cuboText(gl,-5.5f,1f,-3f,2.5f,9,25,0,90,0,5);
         p1.display();    
        gl.glPopMatrix();
        
       
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
