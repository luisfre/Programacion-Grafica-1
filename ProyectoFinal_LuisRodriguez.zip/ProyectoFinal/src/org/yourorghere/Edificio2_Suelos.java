/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Edificio2_Suelos {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1,c3,c4,c5,c6;
    Cubo2 c2;
    Cubo1 c1p2,c2p2,c3p2,c4p2,c5p2,c6p2;
     Cubo1 c1p3,c2p3,c3p3,c4p3,c5p3,c6p3;
    Cubo1 piso1,piso2,piso3,piso4,piso5,piso6,piso7;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    plano tp;
    textPrueba tpr;
    
    ventanas v;

    public Edificio2_Suelos(GL gl, GLUT glut, GLU glu, float ancho, float alto, float profundidad, float x, float y, float z, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

   
    
    
     public void display(){
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
         
         
         
         gl.glPushMatrix();
         //primer piso
         
         c1=new Cubo1(gl,6,1,1,18,1,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();         
         c1=new Cubo1(gl,4.75f,1,-2f,17.5f,1,2.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,15.5f,1.5f,1,1,2,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,15.5f,1.5f,-1,1,2,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,14f,1f,-3f,3,1,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-4.3f,1.5f,1,1,2,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-4.5f,1.5f,-1,1,2,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,-4.5f,1f,-2.13f,1,1,2.1f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,-6f,1.2f,-1,2f,1.4f,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,-4.9f,1.5f,0,0.25f,2,2.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,15.9f,1.5f,0,0.25f,2,2.2f,0,0,0,1f,1f,0.4f);
         c1.display();
        
         
         c1=new Cubo1(gl,9.75f,1,-8.25f,9.5f,1,10.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,0f,1,-7.25f,10f,1,8.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,-4.25f,1.5f,-9.05f,4.5f,2,7.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-4.25f,1f,-3.25f,4.5f,1,4.3f,0,0,0,1f,1f,0.4f);
         c1.display();
         
                 
         
         
         //segundo color
          tp=new plano(gl,-4.4f,-1.7f,1.13f,0.6f,2.1f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
          tp=new plano(gl,-3.7f,1.90f,1.13f,0.6f,0.3f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         
         
         
         tp=new plano(gl,-6.51f,-0.7f,-3.2f,2.2f,1.1f,3.25f,0,-90,0,0.11f,0.21f,0.27f);
         tp.display(); 
         
         tp=new plano(gl,-6.51f,-1.5f,-12.3f,0.5f,2f,3.25f,0,-90,0,0.11f,0.21f,0.27f);
         tp.display(); 
         tp=new plano(gl,8.03f,2.2f,-1.14f,8f,0.15f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         tp=new plano(gl,-0.75f,1.90f,-5.29f,5.75f,0.3f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         tp=new plano(gl,-4.25f,1.90f,-12.81f,2.27f,0.3f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
          tp=new plano(gl,-0.27f,1.90f,-11.81f,5.27f,0.3f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,9.725f,-0.9f,-13.377f,4.76f,1.2f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,-6.51f,1.90f,-8.78f,3.5f,0.3f,3.25f,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,-1.99f,1.90f,-11.52f,1.3f,0.3f,3.25f,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,5.01f,1.90f,-8.58f,3.3f,0.3f,3.25f,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,16.03f,-1.5f,0f,1.15f,2f,3.25f,0,-90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,-6.511f,-0.1f,-3.2f,1f,0.6f,3.25f,0,-90,0,0.1f,0.1f,0.1f);
         tp.display();
       
         
         
         //segundo piso
         c1=new Cubo1(gl,5.5f,2,1,19,1,0.25f,0,0,0,1f,1f,0.4f);
         c1.display(); 
         c1=new Cubo1(gl,5.5f,2,-1,19,1,0.25f,0,0,0,1f,1f,0.4f);
         c1.display();         
         
         c1=new Cubo1(gl,1.25f,2f,-8.55f,7.5f,1,6.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         piso1=new Cubo1(gl,5.5f,1.4f,0f,19,0.2f,2f,0,0,0,1f,1f,0.4f);
         piso1.display();         
         piso1=new Cubo1(gl,5.5f,2.4f,0f,20.75f,0.2f,2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         piso1=new Cubo1(gl,14.5f,1.4f,-2f,3,0.2f,2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         //ventanas
                 
            //primer piso frontal
         v= new ventanas(gl,1.25f,1.2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,-0.28f,1.2f,1.126f,0.26f,0.08f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,6.3f,1.2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,4.9f,1.2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         
           v= new ventanas(gl,11f,1.2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,9.9f,1.2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
     
         v= new ventanas(gl,-1.09f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,-1.09f,1.2f,3f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         
         v= new ventanas(gl,2.09f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,2.09f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,4.11f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,4.11f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,7.09f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,7.09f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,9.11f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,9.11f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,11.59f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,11.59f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,14.61f,1.2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,14.61f,1.2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         //segundo piso frontal
         v= new ventanas(gl,-3.2f,1.7f,1.131f,0.2f,0.11f,0f,0,0,0,4);
         v.display();
         
         v= new ventanas(gl,1.25f,2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,-0.28f,2f,1.126f,0.26f,0.08f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,6.3f,2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,4.9f,2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         
           v= new ventanas(gl,11f,2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,9.9f,2f,1.126f,0.25f,0.08f,0f,0,0,0,5);
         v.display();
     
         v= new ventanas(gl,-1.09f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,-1.09f,2f,3f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         
         v= new ventanas(gl,2.09f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,2.09f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,4.11f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,4.11f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,7.09f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,7.09f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,9.11f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,9.11f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,11.59f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,11.59f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,14.61f,2f,1.8f,0.25f,0.08f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,14.61f,2f,3f,0.25f,0.08f,0f,0,90,0,5);
         v.display();
         
         //segundo piso 
         for (float i = 0.5f; i < 14; i++) {
           v= new ventanas(gl,i,2.3f,-1.131f,0.15f,0.025f,0f,0,0,0,6);
         v.display();  
         }
         
          v= new ventanas(gl,15.3f,2.15f,-1.131f,0.15f,0.04f,0f,0,0,0,7);
         v.display();  
          v= new ventanas(gl,15.3f,1.73f,-1.131f,0.15f,0.04f,0f,0,0,0,7);
         v.display(); 
         
         for (float i = -12f; i <= -2; i=i+0.9f) {
           v= new ventanas(gl,9.96f,1.7f,i,0.15f,0.025f,0f,0,90,0,8);
         v.display(); 
         }
         
         for (float i = -12f; i <= -2; i=i+0.9f) {
           v= new ventanas(gl,8.25f,1.7f,i,0.15f,0.025f,0f,0,90,0,8);
         v.display(); 
         }
         for (float i = -12f; i <= -2; i=i+0.9f) {
           v= new ventanas(gl,6.56f,1.7f,i,0.15f,0.025f,0f,0,90,0,8);
         v.display(); 
         }
         
         v= new ventanas(gl,-6.51f,1.9f,-11.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         
         v= new ventanas(gl,-6.51f,1.9f,-9.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,-6.51f,1.9f,-7.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         
          v= new ventanas(gl,-6.51f,1f,-11.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         
         v= new ventanas(gl,-6.51f,1f,-9.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,-6.51f,1f,-7.05f,0.25f,0.06f,0f,0,-90,0,5);
         v.display();
         
         
         v= new ventanas(gl,-5.75f,1.9f,-12.81f,0.21f,0.06f,0f,0,0,0,5);
         v.display();        
          v= new ventanas(gl,-4.3f,1.9f,-12.81f,0.22f,0.06f,0f,0,0,0,5);
         v.display();
        v= new ventanas(gl,-2.8f,1.9f,-12.81f,0.22f,0.06f,0f,0,0,0,5);
         v.display();
         
           
         v= new ventanas(gl,-5.75f,1f,-12.81f,0.21f,0.06f,0f,0,0,0,5);
         v.display();        
          v= new ventanas(gl,-4.3f,1f,-12.81f,0.22f,0.06f,0f,0,0,0,5);
         v.display();
        v= new ventanas(gl,-2.8f,1f,-12.81f,0.22f,0.06f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,-0.8f,1.8f,-11.81f,0.32f,0.06f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,2.3f,1.8f,-11.81f,0.12f,0.06f,0f,0,0,0,5);
         v.display();         
         v= new ventanas(gl,3.05f,1.8f,-11.81f,0.12f,0.06f,0f,0,0,0,5);
         v.display();         
         v= new ventanas(gl,3.8f,1.8f,-11.81f,0.12f,0.06f,0f,0,0,0,5);
         v.display();         
          v= new ventanas(gl,4.55f,1.8f,-11.81f,0.12f,0.06f,0f,0,0,0,5);
         v.display();
         
          v= new ventanas(gl,-0.8f,1.2f,-11.38f,0.32f,0.04f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,2.3f,1.2f,-11.38f,0.12f,0.04f,0f,0,0,0,5);
         v.display();         
         v= new ventanas(gl,3.05f,1.2f,-11.38f,0.12f,0.04f,0f,0,0,0,5);
         v.display();         
         v= new ventanas(gl,3.8f,1.2f,-11.38f,0.12f,0.04f,0f,0,0,0,5);
         v.display();         
          v= new ventanas(gl,4.55f,1.2f,-11.38f,0.12f,0.04f,0f,0,0,0,5);
         v.display();
            
         v= new ventanas(gl,5.55f,1.2f,-13.48f,0.12f,0.04f,0f,0,0,0,5);
         v.display();
         
         
          v= new ventanas(gl,10f,1.2f,-13.48f,0.03f,0.02f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,12f,1f,-13.48f,0.32f,0.08f,0f,0,0,0,5);
         v.display();
         
         
         
         
         
         
        v= new ventanas(gl,14.51f,1.1f,-4f,0.25f,0.04f,0f,0,90,0,5);
         v.display(); 
         v= new ventanas(gl,14.51f,1.1f,-5.75f,0.25f,0.04f,0f,0,90,0,5);
         v.display(); 
         
         
         
         
         
         
         
         v= new ventanas(gl,14.51f,1.1f,-12.5f,0.25f,0.04f,0f,0,90,0,5);
         v.display(); 
         v= new ventanas(gl,14.51f,1.1f,-10.75f,0.25f,0.04f,0f,0,90,0,5);
         v.display(); 
         v= new ventanas(gl,14.51f,1.1f,-9f,0.25f,0.04f,0f,0,90,0,5);
         v.display(); 
         
         //textura
         
         tpr=new textPrueba(gl,14.51f,1.3f,-12.25f,40f,1f,5,0,-90,0,4);
         tpr.display();
         
         
         
         //Techo
         
         
         gl.glPushMatrix();
           gl.glTranslatef(-5.6f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f( 0.2f , 0.2f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        gl.glPushMatrix();
           gl.glTranslatef(-4f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f( 0.2f , 0.2f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        gl.glPushMatrix();
           gl.glTranslatef(-2.4f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f(  0.2f , 0.2f , 0.2f);
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        gl.glPushMatrix();
           gl.glTranslatef(-0.85f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f(  0.2f , 0.2f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        gl.glPushMatrix();
           gl.glTranslatef(0.75f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f(  0.2f , 0.2f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
       gl.glPushMatrix();
           gl.glTranslatef(2.4f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f(  0.2f , 0.2f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
       
        
        gl.glPushMatrix();
           gl.glTranslatef(4.1f, 1.5f, -5.5f);
           gl.glScalef(0.75f, 0.5f, 2.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f(  0.2f , 0.2f , 0.2f);
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
          gl.glPushMatrix();
           gl.glTranslatef(5.8f, 1.5f, -13.3f);
           gl.glScalef(0.75f, 0.5f, 6.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f( 0.11f,0.21f,0.27f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        c2=new Cubo2(gl,6.23f,1.75f,-7.2f,0.64f,0.5f,12.2f,0,0,0,0.11f,0.21f,0.27f);
         c2.display();
         
         
            gl.glPushMatrix();
           gl.glTranslatef(7.5f, 1.5f, -13.3f);
           gl.glScalef(0.75f, 0.5f, 6.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f( 0.11f,0.21f,0.27f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
                 
        c2=new Cubo2(gl,7.93f,1.75f,-7.2f,0.64f,0.5f,12.2f,0,0,0,0.11f,0.21f,0.27f);
         c2.display();
         
          gl.glPushMatrix();
           gl.glTranslatef(9.2f, 1.5f, -13.3f);
           gl.glScalef(0.75f, 0.5f, 6.2f);           
           gl.glRotatef(0, 0, 1, 0);           
           gl.glColor3f( 0.11f,0.21f,0.27f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        c2=new Cubo2(gl,9.63f,1.75f,-7.2f,0.64f,0.5f,12.2f,0,0,0,0.11f,0.21f,0.27f);
         c2.display();
         
          
         
         //aulas 
         
         c1=new Cubo1(gl,-2.1f,1.5f,2.7f,2,2,3.25f,0,0,0,1f,1f,0.4f);
         c1.display(); 
         tp=new plano(gl,-2.1f,-1.5f,4.33f,1,1.9f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         
         c1=new Cubo1(gl,3.1f,1.5f,2.7f,2,2,3.25f,0,0,0,1f,1f,0.4f);
         c1.display();
         tp=new plano(gl,3.1f,-1.5f,4.33f,1,1.9f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
          c1=new Cubo1(gl,8.1f,1.5f,2.7f,2,2,3.25f,0,0,0,1f,1f,0.4f);
         c1.display(); 
         tp=new plano(gl,8.1f,-1.5f,4.33f,1,1.9f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         
         
         c1=new Cubo1(gl,13.1f,1.5f,2.7f,3,2,3.25f,0,0,0,1f,1f,0.4f);
         c1.display(); 
         tp=new plano(gl,13.1f,-1.5f,4.33f,1.5f,1.9f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         tp.display(); 
         
         
         
         
         //puente
         
         c1=new Cubo1(gl,1.25f,2.4f,-16.75f,1.3f,0.2f,10f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         c1=new Cubo1(gl,1.85f,1.5f,-12.25f,0.1f,2,1f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         c1=new Cubo1(gl,0.65f,1.5f,-12.25f,0.1f,2,1f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         piso1=new Cubo1(gl,1.25f,1.4f,-17.25f,1.3f,0.2f,9f,0,0,0,0.11f,0.21f,0.27f);
         piso1.display(); 
         piso1=new Cubo1(gl,1.85f,1.7f,-16.75f,0.1f,0.4f,10f,0,0,0,0.11f,0.21f,0.27f);
         piso1.display();
         piso1=new Cubo1(gl,0.65f,1.7f,-16.75f,0.1f,0.4f,10f,0,0,0,0.11f,0.21f,0.27f);
         piso1.display();         
         c1=new Cubo1(gl,1.85f,1.5f,-18.25f,0.1f,2,0.25f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         c1=new Cubo1(gl,0.65f,1.5f,-18.25f,0.1f,2,0.25f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         piso1=new Cubo1(gl,1.25f,0.8f,-12.7f,1.3f,0.6f,0.1f,0,0,0,0.11f,0.21f,0.27f);
         piso1.display(); 
         
         
         gl.glPopMatrix();
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
