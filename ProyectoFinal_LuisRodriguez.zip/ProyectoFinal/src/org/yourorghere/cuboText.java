/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;
import java.io.File;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.io.IOException;


/**
 *
 * @author Luis Rodriguez
 */
public class cuboText {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz;
    Texture t1,t2,t3,t4,t5,t6;
    int tipo;
    
    

    public cuboText(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz,int tipo) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.tipo = tipo;
        
        
    }

    public void display(){
         cargarTextura();
          gl.glPushMatrix(); 
        gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof); 
            
         t1.enable();//habilitamos
         t1.bind();//pegamos
          gl.glBegin(gl.GL_QUADS);                                
                
                gl.glTexCoord2f(1, 1);                
                gl.glVertex3f(0, 0, 0);     
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0.2f, 0f, 0);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, 0);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(0f, .2f, 0);                                                                                                                                                                                                                                    
            gl.glEnd();
            
            
            t1.disable();//desabilitar
         
          
          
          
          
           //Cara 2  Verde
          t2.enable();
            t2.bind();           
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0, 0);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(.2f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f,0f);                                
            gl.glEnd();
            t2.disable();
            
            t3.enable();
            t3.bind();
            //Cara 3  Amarillo       
            
            gl.glBegin(gl.GL_QUADS);                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0, -.2f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(0f, .2f,-.2f);                
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
            gl.glEnd();
            t3.disable();
                        
            //Cara 4  ROJO
            t4.enable();
            t4.bind();
            gl.glColor3f(.9f, .1f, .1f);
            gl.glBegin(gl.GL_QUADS);                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.0f, 0, 0f);                               
                                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(0f, .2f,0f);                
                                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(0f, .2f, -.2f);                                                
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, 0f, -.2f);
            gl.glEnd();
            t4.disable();
            
            //Cara 5  Verde Fuerte
            t5.enable();
            t5.bind();
            
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.2f, 0f, 0f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(.2f, 0f, -.2f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(0f, 0f,-.2f);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.0f, 0, 0f);                                                
            gl.glEnd();
            t5.disable();
            
            //Cara 6  morado
            t6.enable();
            t6.bind();
            gl.glColor3f(.3f, .1f, .3f);
            gl.glBegin(gl.GL_QUADS);
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(.2f, .2f, 0f);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, -.2f);
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0f, .2f, -.2f);
                                
                gl.glTexCoord2f(1, 1);
                gl.glVertex3f(.0f, .2f, 0f);                                
                
            gl.glEnd();
            t6.disable();   
         gl.glPopMatrix();
        
        
    }
    
    
      public  void cargarTextura(){
         try{
             if (tipo==0) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso1.gif") , true);
                 
             }else if (tipo==1) {
                  t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso2.gif") , true);
                 
                 
             }else if (tipo==2) {
                t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_1.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_1.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_1.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_1.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3.gif") , true);
             }else if (tipo==3) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto1.gif") , true);
             }else if (tipo==4) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pasto2.gif") , true);
             }else if (tipo==5) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/ladrillo1.gif") , true);
             }else if (tipo==6) {
                t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
                 t2= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
                 t3= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
                 t4= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
                 t5= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
                 t6= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/piso3_2.gif") , true);
             }
            
            
        } catch (IOException ex) {
            System.out.println("no se pudo cargar "+ex);
        }     
        
    }
    


    
    
}
