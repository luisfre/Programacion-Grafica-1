/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Edificio5_LabCivil {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1,c3,c4,c5,c6;
    Cubo2 c2;
    Cubo1 c1p2,c2p2,c3p2,c4p2,c5p2,c6p2;
     
    Cubo1 piso1;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    techo1 t,t1;
     ventanas v;
      plano p;
      textPrueba tpr;

    public Edificio5_LabCivil(GL gl, GLUT glut, GLU glu, float ancho, float alto, float profundidad, float x, float y, float z, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

   
    
    
     public void display(){
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho,alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
         
         
         
         
         
         c1=new Cubo1(gl,1,1,1,19,1,4,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,1,1.6f,1,19.4f,0.2f,4.4f,0,0,0,0.11f,0.21f,0.27f);
         c1.display();
         
         
        
         
         for (float i = -6.8f; i < 10.1; i=i+1.2f) {
             t=new techo1(gl,i,1.6f,3.2f,0.15f,0.075f,0.55f,0,0,0,0.11f,0.21f,0.27f);         
         t.display();  
         }
         
          t=new techo1(gl,-8f,1.6f,3.2f,0.15f,0.075f,0.55f,0,0,0,0.11f,0.21f,0.27f);         
         t.display();
         
         //ventanas
          for (float i = -8f; i < 10.1; i=i+1.2f) {
          v= new ventanas(gl,i,1.33f,3.01f,0.14f,0.03f,0f,0,0,0,5);
         v.display(); 
         }
         
         for (float i = -8f; i < 10.1; i=i+1.2f) {
          v= new ventanas(gl,i,1.33f,-1.01f,0.14f,0.03f,0f,0,0,0,5);
         v.display(); 
         }
         
         for (float i = -0.7f; i < 2.8f; i=i+0.4f) {
         v= new ventanas(gl,10.51f,1.33f,i,0.07f,0.03f,0f,0,90,0,5);
         v.display();
         }
          for (float i = -0.7f; i < 2.8f; i=i+0.4f) {
         v= new ventanas(gl,-8.51f,1.33f,i,0.07f,0.03f,0f,0,90,0,5);
         v.display();
         }
         
         
         
        
         
          p=new plano(gl,-5.3f,-0.1f,3.01f,0.15f,0.6f,3.25f,0,0,0,0.11f,0.21f,1f);
         p.display();
         
         p=new plano(gl,-4.8f,0f,3.01f,0.15f,0.5f,3.25f,0,0,0,0.11f,0.21f,0.27f);
         p.display();
         
         
          p=new plano(gl,0.4f,-0.1f,3.01f,0.25f,0.6f,3.25f,0,0,0,0.1f,0.1f,0.1f);
         p.display();
         
         p=new plano(gl,5.2f,-0.1f,3.01f,0.25f,0.6f,3.25f,0,0,0,0.1f,0.1f,0.1f);
         p.display();
         
          for (float i = -4.4f; i < -2; i=i+1.2f) {
          v= new ventanas(gl,i,0.9f,-1.01f,0.14f,0.05f,0f,0,0,0,5);
         v.display(); 
         }
          
         for (float i = -2f; i < 1; i=i+1.2f) {
          v= new ventanas(gl,i,0.9f,-1.01f,0.14f,0.05f,0f,0,0,0,5);
         v.display(); 
         }
         v= new ventanas(gl,10.25f,0.9f,-1.01f,0.06f,0.05f,0f,0,0,0,5);
         v.display(); 
         
         v= new ventanas(gl,9.8f,0.9f,-1.01f,0.06f,0.05f,0f,0,0,0,5);
         v.display(); 
         tpr=new textPrueba(gl,-8.5f,0.5f,-1.01f,17f,3.8f,5,0,0,0,5);
         tpr.display();
        
         
         
         
        
        
         
         
         
         
         
         
         
         
         
         
       
         
         
         
         
         
    
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
