package org.yourorghere;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;
import java.io.File;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.io.IOException;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.Serializable;
/**
 * ProyectoFinal.java <BR>
 * author: Luis rodriguez
 * <P>
 *
 * This version is equal to Brian Paul's version 1.2 1999/10/21
 */
public class ProyectoFinal implements GLEventListener, KeyListener {

    //------------------*************************------------------//
    //NACIMIENTO DE VARIABLES
     static float transx = 4.1f, transy = 1,transz=17.4f;
    int cam = 1;
     static float radio=45; 
             float angulo = 0;
    float color=0;
    Edificio1_Lab e1;
    Edificio2_Suelos e2;
    Edificio3_Aulas e3;
    Edificio4_LabIndus e4;
    Edificio5_LabCivil e5;
    Edificio6_nuevo e6;
    Mundo m1;
    Cubo1 c1;
   Persona probando;
    static double vistx = 0;
    static double visty = 0;
    static double vistz = 0;
    
   
    
    

   

    //FIN DE NACIMIENTO DE VARIABLES
    //------------------*************************------------------//
    public static void main(String[] args) {
        Frame frame = new Frame("Proyecto");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new ProyectoFinal());
        frame.add(canvas);
        frame.setSize(1000, 500);
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));
        GL gl = drawable.getGL();
        GLU glu = new GLU();
        GLUT glut = new GLUT();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);

        // Setup the drawing area and shading mode
        gl.glClearColor(0.4f, 0.9f, 0.9f, 0.0f);
        gl.glShadeModel(GL.GL_SMOOTH); // try setting this to GL_FLAT and see what happens.
        drawable.addKeyListener(this);
        //------------------*************************------------------//
        //INICIALIZACION DE VARIABLES
        
        e1= new Edificio1_Lab(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        e2= new Edificio2_Suelos(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        e3= new Edificio3_Aulas(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        e4= new Edificio4_LabIndus(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        e5= new Edificio5_LabCivil(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        e6= new Edificio6_nuevo(gl,glut,glu,1,1,1,1,1,1,0,0,0);
        m1= new Mundo(gl,glut,glu,2,2,2,1,1,1,0,0,0);
        probando= new Persona(gl,7f,2.4f,28f,0.4f,0.4f,0.4f,0f,180f,0f,"parado",0);
         
         
        //FIN DE INICIALIZACION DE VARIABLES
        //------------------*************************------------------//
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!

            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 1.0, 300);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();
        GLUT glut = new GLUT();

        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glTexEnvi(gl.GL_TEXTURE_ENV,gl.GL_TEXTURE_ENV_MODE, gl.GL_DECAL);

        // Move the "drawing cursor" around
        gl.glTranslatef(0.0f, 0.0f, 0.0f);

        //------------------*************************------------------//
        //CAMARAS
        // glu.gluLookAt(0, 0, 1, 0, 0, 0, 0, 1, 0);//<-- Este es como referencia asi se ve la camara cuando esta en la misma posicion por defecto
        if (cam == 1) {
            probando.avanzar();
            glu.gluLookAt(probando.x , probando.y+0.4f , probando.z+1.2f, probando.x , probando.y , probando.z, 0, 1, 0);
        }
        if (cam == 2) {
            glu.gluLookAt(0, 175, -5, 0, 34, -40, 0, 1, 0);
            //glu.gluLookAt(-85, 15, 45, -20, 10, 0, 0, 1, 0);
           //glu.gluLookAt((radio * Math.sin(angulo)), 1, (radio * Math.cos(angulo)), 0, 0, 0, 0, 1, 0);
        }
        if (cam == 3) {
            probando.avanzar();
            glu.gluLookAt(-15, 15, 45, probando.x , probando.y , probando.z, 0, 1, 0);
            //glu.gluLookAt(1, (radio * Math.sin(angulo)), (radio * Math.cos(angulo)), 0, 0, 0, 0, 1, 0);
        }
        
        if (cam == 4) {
             glu.gluLookAt((float)Math.cos(angulo)*radio, 10, (float)Math.sin(angulo)*radio, 10,10,-20, 0, 1, 0);
        }
        if (cam == 5) {
            glu.gluLookAt((float)Math.cos(angulo)*30f, 10, (float)Math.sin(angulo)*40f, 40,10,-20, 0, 1, 0);
        }
        
        //FINAL CAMARAS
        //------------------*************************------------------//
        //EMPEZAR A DIBUJAR
        //-----------------------------------------*************************-----------------------------------------//
       
        //cos2=(float)Math.cos(angulo)*4f;
      
        
      //e1.display();
        probando.Display();
     m1.display();
       //e2.display();
       //e3.display();
       //e4.display();
       //e5.display();
        //e6.display();
      
        
         
        
       
       
        //-----------------------------------------*************************-----------------------------------------//
        //TERMINAR DE DIBUJAR
        //------------------*************************------------------//

        
        
        
        
        
        
        
        gl.glFlush();
        //Variables contadoras que incrementan o decrementan
        angulo = angulo + 0.1f;
        color=color+(float)(Math.random()*1)+0.1f;
        
        
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }

    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void keyPressed(KeyEvent e) {
        //EVENTOS DE TECLADO PARA QUE SE MUEVAN EN X Y Z
       
        if (e.getKeyCode() == KeyEvent.VK_UP ) {
            radio = radio + 2;
            System.out.println(transy);
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN ) {
            radio = radio - 2;
            System.out.println(transy);

        }
        
         if ( e.getKeyCode() == KeyEvent.VK_W) {
            transz = transz - 1;
            System.out.println(transz);
        }
        if ( e.getKeyCode() == KeyEvent.VK_S) {
            transz = transz + 1;
            System.out.println(transz);

        }
        //------------------*************************------------------//
        //EVENTOS DE TECLADO PARA LAS CAMARAS
        if (e.getKeyCode() == KeyEvent.VK_1) {
            cam = 1;

        }
        if (e.getKeyCode() == KeyEvent.VK_2) {
            cam = 2;

        }
        if (e.getKeyCode() == KeyEvent.VK_3) {
            cam = 3;

        }
        if (e.getKeyCode() == KeyEvent.VK_4) {
            cam = 4;

        }
        if (e.getKeyCode() == KeyEvent.VK_5) {
            cam = 5;

        }
    }

    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
    
   
    
    
}
