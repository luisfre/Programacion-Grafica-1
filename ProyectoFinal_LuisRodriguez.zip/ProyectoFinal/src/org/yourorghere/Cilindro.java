package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

public class Cilindro {

    GL gl;
    GLUT glut;
    double R, A;
    int sl, st;
    float r, g, b;

    public Cilindro(GL gl, GLUT glut, double R, double A, int sl, int st, float r, float g, float b) {
        this.gl = gl;
        this.glut = glut;
        this.R = R;
        this.A = A;
        this.sl = sl;
        this.st = st;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public void DrawCilindro(float angle, float PX, float PY, float PZ) {
        gl.glPushMatrix();
        gl.glTranslatef(PX,PY,PZ);
        gl.glRotated(angle, 1, 0, 0);
        gl.glColor3f(1,1,1);
        glut.glutWireCylinder(R,A,sl,st);
        gl.glColor3f(r,g,b);
        glut.glutSolidCylinder(3,2,100,100);
        gl.glPopMatrix();
    }

}
