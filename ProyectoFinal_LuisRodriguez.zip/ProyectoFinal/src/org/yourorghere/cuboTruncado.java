/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author Abigail Proa�o
 */
public class cuboTruncado {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz,r,g,b;

    public cuboTruncado(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz, float r, float g, float b) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public void display(){
        
         gl.glPushMatrix();
           
        
         gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof);   
         gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(-4,1,0);           
           gl.glVertex3d(4,1,0);
           gl.glVertex3d(4,3,0);//2
           gl.glVertex3d(-4,4,0);//1
        gl.glEnd();
        
         gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(-4,1,-4);           
           gl.glVertex3d(4,1,-4);
           gl.glVertex3d(4,3,-4);//2
           gl.glVertex3d(-4,4,-4);//1
        gl.glEnd();
        
        gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(4,1,0);           
           gl.glVertex3d(4,1,-4);
           gl.glVertex3d(4,3,-4);//2
           gl.glVertex3d(4,3,0);//1
        gl.glEnd();
        
         gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(-4,1,0);           
           gl.glVertex3d(-4,1,-4);
           gl.glVertex3d(-4,4,-4);//2
           gl.glVertex3d(-4,4,0);//1
        gl.glEnd();
        
        gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(-4,4,0);           
           gl.glVertex3d(4,3,0);
           gl.glVertex3d(4,3,-4);//2
           gl.glVertex3d(-4,4,-4);//1
        gl.glEnd();
        
        gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(r,g,b);
           gl.glVertex3d(-4,1,0);           
           gl.glVertex3d(4,1,0);
           gl.glVertex3d(4,1,-4);//2
           gl.glVertex3d(-4,1,-4);//1
        gl.glEnd();
         

          gl.glPopMatrix();
        
        
        
    }
    


    
    
}
