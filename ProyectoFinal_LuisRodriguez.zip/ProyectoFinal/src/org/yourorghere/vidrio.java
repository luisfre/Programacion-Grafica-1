/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author Luis Rodriguez
 */
public class vidrio {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz,r,g,b;
    int tipo;

    public vidrio(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz, float r, float g, float b,int tipo) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.r = r;
        this.g = g;
        this.b = b;
        this.tipo=tipo;
    }

    public void display(){
        
         gl.glPushMatrix();
           
        
         gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof);
         
         if (tipo==0) {
             
              gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(0.69f,0.79f,0.84f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(0.69f,0.79f,0.84f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.82f,0.88f,0.94f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.82f,0.88f,0.94f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
        }else if (tipo==1) {
         gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(0f,0f,0f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(0f,0f,0f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.69f,0.79f,0.84f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.69f,0.79f,0.84f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
            
        }else if (tipo==2) {
         gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(1f,1f,0.4f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(1f,1f,0.4f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.6f,0.6f,0.6f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.6f,0.6f,0.6f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
            
        }else if (tipo==3) {
            gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(0.7f,0.7f,0.7f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(0.7f,0.7f,0.7f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.8f,0.8f,0.8f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.8f,0.8f,0.8f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
        }else if (tipo==4) {
            gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(0.2f,0.2f,0.2f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(0.2f,0.2f,0.2f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.5f,0.5f,0.2f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.5f,0.5f,0.2f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
        }else if (tipo==5) {
            gl.glBegin(gl.GL_QUADS);
           
           gl.glColor3f(0.2f,0.2f,0.2f);
           gl.glVertex3d(-1,1,0); 
           gl.glColor3f(0.2f,0.2f,0.2f);
           gl.glVertex3d(1,1,0);
           gl.glColor3f(0.11f,0.21f,0.27f);
           gl.glVertex3d(1,2,0);//2
           gl.glColor3f(0.11f,0.21f,0.27f);
           gl.glVertex3d(-1,2,0);//1
        gl.glEnd();
            
        }
        
        
        

          gl.glPopMatrix();
        
        
        
    }
    


    
    
}
