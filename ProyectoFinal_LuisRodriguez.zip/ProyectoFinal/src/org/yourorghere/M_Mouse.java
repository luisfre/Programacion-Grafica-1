package org.yourorghere;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/*
 * @author zahy
 */
public class M_Mouse implements MouseListener, MouseMotionListener {

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.isMetaDown()) {
            ProyectoFinal.vistz = ProyectoFinal.vistz + 10;
        } else {
            ProyectoFinal.vistz = ProyectoFinal.vistz - 10;
        }
        
        System.out.println("si");
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

        int x = e.getX();
        int y = e.getY();

        if (x < 250) {
            ProyectoFinal.vistx = ProyectoFinal.vistx - 10;
        }
        if (x > 350) {
            ProyectoFinal.vistx = ProyectoFinal.vistx + 10;
        }

        if (y < 250) {
            ProyectoFinal.visty = ProyectoFinal.visty + 10;
        }
        if (y > 350) {
            ProyectoFinal.visty = ProyectoFinal.visty - 10;
        }
    }
}
