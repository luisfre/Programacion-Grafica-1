/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;
import java.io.File;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.io.IOException;


/**
 *
 * @author Luis Rodriguez
 */
public class textPrueba {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz;
    Texture t1;
    int tipo;
    
    

    public textPrueba(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz,int tipo) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.tipo = tipo;
        
        
    }

    public void display(){
         cargarTextura();
          gl.glPushMatrix(); 
        gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof); 
            
         t1.enable();//habilitamos
         t1.bind();//pegamos
               
         gl.glPushMatrix();
         gl.glScalef(1, 1, 0);            
         gl.glBegin(gl.GL_QUADS);                                
                
                gl.glTexCoord2f(1, 1);                
                gl.glVertex3f(0, 0, 0);     
                
                gl.glTexCoord2f(0, 1);
                gl.glVertex3f(0.2f, 0f, 0);
                
                gl.glTexCoord2f(0, 0);
                gl.glVertex3f(.2f, .2f, 0);
                
                gl.glTexCoord2f(1, 0);
                gl.glVertex3f(0f, .2f, 0);                                                                                                                                                                                                                                    
            gl.glEnd();
            
            gl.glPopMatrix();
            t1.disable();//desabilitar
          gl.glPopMatrix();
        
        
        
    }
    
    
      public  void cargarTextura(){
         try{
             if (tipo==0) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/mural1.gif") , true);
             }else if (tipo==1) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/letrerocisco1.gif") , true);
                 
                 
             }else if (tipo==2) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/mural2.gif") , true);
             }else if (tipo==3) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/cisco.gif") , true);
             }else if (tipo==4) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/nombrefacu.jpg") , true);
             }else if (tipo==5) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pared.gif") , true);
             }else if (tipo==6) {
                 t1= TextureIO.newTexture(new File("src/org/yourorghere/Texturas/pared2.gif") , true);
             }
            
            
        } catch (IOException ex) {
            System.out.println("no se pudo cargar "+ex);
        }     
        
    }
    


    
    
}
