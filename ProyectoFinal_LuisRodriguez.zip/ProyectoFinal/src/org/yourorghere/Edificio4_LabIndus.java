/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Edificio4_LabIndus {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1,c3,c4,c5,c6;
    Cubo2 c2;
    Cubo1 c1p2,c2p2,c3p2,c4p2,c5p2,c6p2;
     Cubo1 c1p3,c2p3,c3p3,c4p3,c5p3,c6p3;
    Cubo1 piso1,piso2,piso3,piso4,piso5,piso6,piso7;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    techo1 t;
     plano tp;
     ventanas v;
     
    public Edificio4_LabIndus(GL gl, GLUT glut, GLU glu, float ancho, float alto, float profundidad, float x, float y, float z, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

   
    
    
     public void display(){
         gl.glPushMatrix();
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
         
         
       
         
         c1=new Cubo1(gl,1,1,1,6,1,4,0,0,0,2,2,2);
         c1.display();
         
         c1=new Cubo1(gl,1,1.7f,1,6.4f,0.6f,4.4f,0,0,0,0.4f,0.4f,0.4f);
         c1.display();                
         
                 
         t=new techo1(gl,4.21f,1.8f,1,0.29f,0.07f,0.8f,0,90,0,0.4f,0.4f,0.4f);         
         t.display();
         
         
         tp=new plano(gl,3.95f,-0.5f,3.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();
          tp=new plano(gl,2.2f,-0.5f,3.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();         
          tp=new plano(gl,0f,-0.5f,3.01f,0.5f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,-1.9f,-0.5f,3.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();
         
         tp=new plano(gl,3.9f,-0.5f,-1.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();
         tp=new plano(gl,2.2f,-0.5f,-1.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,0f,-0.5f,-1.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,-1.9f,-0.5f,-1.01f,0.1f,1f,5,0,0,0,0.4f,0.4f,0.4f);
         tp.display();
         
         
         tp=new plano(gl,4.001f,-0.5f,-0.85f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,4.001f,-0.5f,0.85f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,4.001f,-0.5f,2.8f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();
         
         tp=new plano(gl,-2.001f,-0.5f,-0.85f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,-2.001f,-0.5f,0.85f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();         
         tp=new plano(gl,-2.001f,-0.5f,2.8f,0.2f,1f,5,0,90,0,0.4f,0.4f,0.4f);
         tp.display();
         
         //ventanas
                 
         
         v= new ventanas(gl,1.28f,1.33f,3.01f,0.28f,0.03f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,4.01f,1.33f,1.82f,0.25f,0.03f,0f,0,90,0,5);
         v.display();
         
         v= new ventanas(gl,4.01f,1.33f,0f,0.2f,0.03f,0f,0,90,0,5);
         v.display();
        
         v= new ventanas(gl,1.48f,1.33f,-1.01f,0.2f,0.03f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,-0.68f,1.33f,-1.01f,0.2f,0.03f,0f,0,0,0,5);
         v.display();
         
         gl.glPopMatrix();
         
         
         
         
       
         
         
         
         
         
    
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
