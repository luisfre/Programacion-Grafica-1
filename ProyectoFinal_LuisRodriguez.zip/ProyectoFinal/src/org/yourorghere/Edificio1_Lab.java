/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Edificio1_Lab {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1;    
    Cubo1 piso1;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    plano tp;
    textPrueba tpr;    
    ventanas v;
    cuboText p1;
    cuboText1 p2;
    Escalera esc;
    Meseta m1;
    

    public Edificio1_Lab(GL gl, GLUT glut, GLU glu, float x, float y, float z,float ancho, float alto, float profundidad, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

   
    
    
     public void display(){
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
        
        
        //subsuelo
        c1=new Cubo1(gl,11.75f,-0.1f,0,13.25f,1,8,0,0,0,1f,1f,0.4f);
         c1.display();
         
         tp=new plano(gl,13.5f,-1.6f,4.01f,0.5f,1f,5,0,0,0,0.1f,0.1f,0.1f);
         tp.display(); 
         
         tpr=new textPrueba(gl,5.1f,-0.6f,4.01f,13f,4.8f,5,0,0,0,6);
         tpr.display();
         
         tpr=new textPrueba(gl,15.78f,-0.6f,4.01f,13f,4.8f,5,0,0,0,6);
         tpr.display();
         tpr=new textPrueba(gl,7.4f,-0.6f,4.01f,28f,2.4f,5,0,0,0,6);
         tpr.display();
         
          tpr=new textPrueba(gl,14f,-0.6f,4.01f,10f,2.4f,5,0,0,0,6);
         tpr.display();
         
         for (float i = 8; i < 12.6; i=i+0.9f) {
              v= new ventanas(gl,i,0.1f,4.01f,0.13f,0.06f,0f,0,0,0,3);
         v.display();
         }
         
        
         
          v= new ventanas(gl,14.5f,0.1f,4.01f,0.13f,0.06f,0f,0,0,0,3);
         v.display();
           v= new ventanas(gl,15.35f,0.1f,4.01f,0.13f,0.06f,0f,0,0,0,3);
         v.display();
         
         
         
         
         //primer piso       
        
         c1=new Cubo1(gl,1,1,1,5,1,5,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,10.5f,1,2.5f,11,1,2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,10.5f,1,-0.5f,11,1,2.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,11f,1,0.4f,10,1,2.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,11.75f,1,-2.3f,12f,1,5.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-3.2f,1,0,3.4f,1,3,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-0.7f,1,-3f,8.4f,1,3,0,0,0,1f,1f,0.4f);        
         c1.display();
         
         //ventanas
        
         v= new ventanas(gl,14.89f,0.97f,0.51f,0.075f,0.14f,0.5f,0,0,0,0);
         v.display(); 
         v= new ventanas(gl,14.4f,0.97f,0.51f,0.075f,0.14f,0.5f,0,0,0,0);
         v.display(); 
         
         v= new ventanas(gl,13.91f,0.97f,0.51f,0.075f,0.14f,0.5f,0,0,0,0);
         v.display(); 
         
          for (float i = 6.22f; i <13.42f; i=i+0.49f) {
            v= new ventanas(gl,i,0.97f,0.51f,0.075f,0.14f,0.5f,0,0,0,0);
         v.display();
         }
         
          for (float i = 6.22f; i <17.5f; i=i+0.49f) {
            v= new ventanas(gl,i,0.9f,-8.1f,0.08f,0.05f,0.5f,0,0,180,0);
         v.display();
         }
         
         v= new ventanas(gl,13.42f,0.97f,0.51f,0.075f,0.14f,0.5f,0,0,0,0);
         v.display();        
          v= new ventanas(gl,-0.9f,1.45f,0.51f,0.2f,0.02f,0.5f,0,0,0,3);
           v.display();
          v= new ventanas(gl,1.29f,1.45f,0.51f,0.2f,0.02f,0.5f,0,0,0,3);
           v.display();
           v= new ventanas(gl,2.59f,1.45f,0.51f,0.2f,0.02f,0.5f,0,0,0,3);
           v.display();
           
           v= new ventanas(gl,1.48f,0.88f,1.95f,0.15f,0.1f,0.5f,0,-90,0,3);
           v.display();
           
           v= new ventanas(gl,-2.2f,0.88f,-1.4f,0.15f,0.1f,0.5f,0,0,0,2);
           v.display();
           
           
           
           
         
         
         
         //segundo color pared
         tp=new plano(gl,10.5f,0f,3.55f,5.5f,0.5f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();         
         tp=new plano(gl,1.02f,0f,3.55f,2.5f,0.5f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();        
         tp=new plano(gl,0.2f,-1.5f,3.56f,0.5f,2f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,15.6f,-1.5f,3.56f,0.5f,2f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,-1.51f,-1.5f,2.49f,1.1f,2f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,16.1f,-1.5f,2f,1.6f,2f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         //Escalera
         p2= new cuboText1(gl,-4.81f,0.35f,4.2f,118,0.6f,69f,0,0,0,0.3f,0.3f,0.3f);
         p2.display(); 
         
         esc= new Escalera(gl,glut,glu,-0.06f,-0.25f,0.03f,1,1.7f,1f,0,0,0,5);
         esc.display();
         p2= new cuboText1(gl,2.5f,-0.47f,7.3f,15,0.6f,52,0,0,0,0.3f,0.3f,0.3f);
         p2.display(); 
         
         p2= new cuboText1(gl,-7.4f,-0.55f,7.4f,65.5f,0.6f,52.5f,0,0,0,0.3f,0.3f,0.3f);
         p2.display(); 
         m1= new Meseta(gl,12f,-1.5f,8f,1.7f,0.5f,0.25f,0f,0f,0f);
         m1.display(); 
         esc= new Escalera(gl,glut,glu,4.46f,-0.95f,2.6f,0.3f,1f,1f,0,90,0,3);
         esc.display();
         
         
         
        
         
         //segundo piso
         c1=new Cubo1(gl,1.5f,2,2.8f,6f,1,1.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,9.5f,2,2f,7f,1,3f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,5.5f,2,1.6f,1f,1,0.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,5.5f,2,-0.5f,1f,1,2.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,1f,2,0.5f,5f,1,4f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,14.7f,2,2.4f,3.5f,1,3.8f,0,0,0,1f,1f,0.4f);
         c1.display();          
         piso1=new Cubo1(gl,5.4f,1.6f,2.9f,15.2f,0.2f,2.8f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         piso1=new Cubo1(gl,2.25f,1.6f,-1.9f,7.5f,0.2f,1f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         piso1=new Cubo1(gl,4.25f,1.6f,0f,1.8f,0.2f,3f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         //ventanas
         for (float i = 6.2f; i <12.4f; i=i+1) {
           v= new ventanas(gl,i,2f,0.51f,0.05f,0.14f,0.5f,0,0,0,1);
           v.display();
         }
         
         v= new ventanas(gl,-0.9f,2.08f,0.57f,0.2f,0.1f,0.5f,0,0,0,3);
           v.display();
         v= new ventanas(gl,1.29f,2.08f,0.57f,0.2f,0.1f,0.5f,0,0,0,3);
         v.display();
         v= new ventanas(gl,2.59f,2.08f,0.57f,0.2f,0.1f,0.5f,0,0,0,3);
         v.display();
         v= new ventanas(gl,3.89f,2.08f,0.57f,0.2f,0.1f,0.5f,0,0,0,3);
         v.display();
         v= new ventanas(gl,15.84f,1.95f,1.31f,0.2f,0.13f,0.5f,0,0,0,3);
         v.display();
         v= new ventanas(gl,13.6f,1.95f,1.31f,0.2f,0.13f,0.5f,0,0,0,3);
         v.display();
         v= new ventanas(gl,14.72f,1.95f,1.31f,0.17f,0.13f,0.5f,0,0,0,3);
         v.display();
         for (float i = 0.81f; i <3.82f; i=i+1f) {
           v= new ventanas(gl,19.46f,1.95f,i,0.17f,0.13f,0.5f,0,-90,0,3);
         v.display();
         }
        
         
        
         v= new ventanas(gl,1.48f,2.08f,1.95f,0.15f,0.1f,0.5f,0,-90,0,3);
           v.display();
         
         
         
        
         
         
         //tercer piso
         
         piso1=new Cubo1(gl,9.6f,2.6f,2.9f,13.75f,0.2f,2.8f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         piso1=new Cubo1(gl,12.98f,2.6f,1.9f,7f,0.2f,2.8f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         piso1=new Cubo1(gl,1.8f,2.6f,1.5f,6.4f,0.2f,5f,0,0,0,0.85f,0.85f,0.85f);
         piso1.display();
         c1=new Cubo1(gl,0.8f,3,3.8f,6f,1,1f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,6.25f,3,3.55f,5f,1,0.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,6.8f,3,2.1f,4f,1,1.2f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,9f,3,2.65f,1f,1,2.3f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,7.75f,3,1f,3.5f,1,1f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,-1.7f,3,0.7f,1f,1,6.4f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,2f,3,-1.75f,8f,1,1.5f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,5.5f,3,-0.4f,1f,1,2f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,1.6f,3,2f,3.5f,1,4f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,3.4f,3,1.4f,0.5f,1,2.8f,0,0,0,1f,1f,0.4f);
         c1.display();
          for (float i = -1.9f; i < 3.41f; i=i+0.65f) {
           v= new ventanas(gl,i,2.95f,1.31f,0.1f,0.14f,0.5f,0,0,0,2);
           v.display();  
         }
         for (float i = -2.15f; i < 3.99f; i=i+0.68f) {
           v= new ventanas(gl,0.79f,2.95f,i,0.108f,0.14f,0.5f,0,-90,0,2);
           v.display();  
         }
         
         for (float i = -1.9f; i < 6.41f; i=i+0.65f) {
           v= new ventanas(gl,i,2.95f,0.49f,0.1f,0.14f,0.5f,0,180,0,2);
           v.display(); 
         }
         for (float i = 4.5f; i < 10f; i=i+1.1f) {
           v= new ventanas(gl,i,3f,0.81f,0.17f,0.11f,0.5f,0,0,0,3);
         v.display();   
         }
         
         
          
         //techo
         
         piso1=new Cubo1(gl,5.6f,3.6f,2.4f,9f,0.2f,3.8f,0,0,0,0.16f,0.315f,0.405f);
         piso1.display();
         piso1=new Cubo1(gl,1.85f,3.6f,0.8f,8.3f,0.2f,7f,0,0,0,0.16f,0.315f,0.405f);
         piso1.display();
         piso1=new Cubo1(gl,-3.265f,1.7f,0,3.65f,0.4f,3.25f,0,0,0,0.16f,0.315f,0.405f);
         piso1.display();
         piso1=new Cubo1(gl,-0.8f,1.7f,-3f,8.6f,0.4f,3.25f,0,0,0,0.16f,0.315f,0.405f);
         piso1.display();
         
         gl.glPushMatrix();
           gl.glTranslatef(5.75f, 2.2f, -1.9f);
           gl.glScalef(6f, 2f, 3);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f( 0.7f , 0.4f , 0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        
        gl.glPushMatrix();
           gl.glTranslatef(5.7f, 2.2f, -1.9f);
           gl.glScalef(0.2f, 2f, 3);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f( 0.5f,0.5f,0.2f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
          gl.glPushMatrix();
           gl.glTranslatef(17.61f, 2.2f, -1.9f);
           gl.glScalef(0.1f, 2f, 3);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f( 1f,1f,0.4f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
              
        
        gl.glPushMatrix();
           gl.glTranslatef(5.8f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f( 0.7f , 0.3f , 0f );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
         
        gl.glPushMatrix();
           gl.glTranslatef(7.3f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
         
        gl.glPushMatrix();
           gl.glTranslatef(8.9f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
          gl.glPushMatrix();
           gl.glTranslatef(10.3f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
          gl.glPushMatrix();
           gl.glTranslatef(11.8f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        
        
          gl.glPushMatrix();
           gl.glTranslatef(13.3f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        
        
          gl.glPushMatrix();
           gl.glTranslatef(14.8f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        
        
          gl.glPushMatrix();
           gl.glTranslatef(16.3f, 2.3f, -1.9f);
           gl.glScalef(0.25f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        
        gl.glPushMatrix();
           gl.glTranslatef(17.4f, 2.3f, -1.9f);
           gl.glScalef(0.15f, 2f, 3.1f);           
           gl.glRotatef(90, 0, 1, 0);           
           gl.glColor3f(  0.7f , 0.3f , 0f  );
           glut.glutSolidCylinder(1, 2, 50, 50);

        gl.glPopMatrix();
        
        c1=new Cubo1(gl,11.74f,2f,-2.25f,12f,1.5f,6.1f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         for (float i = 6; i < 16.6; i=i+0.8f) {
            v= new ventanas(gl,i,1.94f,-2.31f,0.12f,0.18f,0.5f,0,180,0,2);
           v.display();   
         }
         
         v= new ventanas(gl,17.26f,1.94f,-2.31f,0.14f,0.18f,0.5f,0,180,0,2);
           v.display();
        
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
