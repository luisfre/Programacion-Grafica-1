/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Escalera {
    
    GL gl;
    GLUT glut;
    GLU glu;
    float ancho,alto,profundidad;
    int nGradas;
    float x,y,z;
    float rx,ry,rz;
    cuboText1 p1;
    

    public Escalera(GL gl, GLUT glut, GLU glu, float x, float y, float z, float ancho, float alto, float profundidad ,float rx, float ry, float rz,int nGradas) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.nGradas = nGradas;
    }

   
    
    
     public void display(){
        gl.glPushMatrix();
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
        
        
           
         
            
         float px=-4.9f,py=0.27f,pz=4.3f,tx=52,tz=52;
         
         //escalera
         for (int i = 0; i <= nGradas; i++) {
            p1= new cuboText1(gl,px,py,pz,tx,0.6f,tz,0,0,0,0.3f,0.3f,0.3f);
         p1.display(); 
         px=px-0.09f;
         py=py-0.08f;
         pz=pz+0.1f;
         tx=tx+0.5f;
         tz=tz+0.5f;
         }
              
        
        
        gl.glPopMatrix();
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
