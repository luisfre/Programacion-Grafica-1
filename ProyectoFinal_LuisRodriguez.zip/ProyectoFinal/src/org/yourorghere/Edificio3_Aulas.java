/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Edificio3_Aulas {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1,c3,c4,c5,c6;
    Cubo2 c2;
    Cubo1 c1p2,c2p2,c3p2,c4p2,c5p2,c6p2;
     Cubo1 c1p3,c2p3,c3p3,c4p3,c5p3,c6p3;
    Cubo1 piso1,piso2,piso3,piso4,piso5,piso6,piso7;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    plano tp;
    textPrueba tpr;
    ventanas v;

    public Edificio3_Aulas(GL gl, GLUT glut, GLU glu, float ancho, float alto, float profundidad, float x, float y, float z, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

   
    
    
     public void display(){
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho,alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
         
         
         c1=new Cubo1(gl,6,2.5f,1,3.5f,4,3f,0,0,0,1f,1f,0.4f);
         c1.display();  
         
         c1=new Cubo1(gl,3.8f,2.5f,-2,4,4,3f,0,0,0,1f,1f,0.4f);
         c1.display();
         c1=new Cubo1(gl,4.9f,2.5f,-5,1.8f,4,3f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,5.95f,2.5f,-5.1f,0.2f,4,1f,0,0,0,1f,1f,0.4f);
           c1.display();
        gl.glPopMatrix();
       
        c1=new Cubo1(gl,6.8f,2.5f,-8.75f,10,4,3f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,10.8f,2.5f,-4.2f,2,4,7.4f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         //segundo color
         tp=new plano(gl,6f,-1.9f,2.51f,1.75f,3.2f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         
        
         
         tp=new plano(gl,7.76f,2.68f,1f,1f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,7.76f,1.68f,1f,1f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,7.76f,0.68f,1f,1f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,4.24f,2.68f,0.5f,1.5f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,4.24f,1.68f,0.5f,1.5f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,4.24f,0.68f,0.5f,1.5f,0.6f,5,0,90,0,0.11f,0.21f,0.27f);
         tp.display();
         
         tp=new plano(gl,3.7f,2.68f,-0.49f,1.5f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,3.7f,1.68f,-0.49f,1.5f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,3.7f,0.68f,-0.49f,1.5f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         
         
        tp=new plano(gl,11.81f,-3.5f,-10f,0.25f,4f,5,0,90,0,0.11f,0.21f,0.27f);
        tp.display();
        tp=new plano(gl,11.81f,-3.5f,-0.735f,0.25f,4f,5,0,90,0,0.11f,0.21f,0.27f);
        tp.display();
         tp=new plano(gl,11.81f,-3.5f,-4f,0.1f,4f,5,0,90,0,0.11f,0.21f,0.27f);
        tp.display();
          tp=new plano(gl,11.81f,-3.5f,-7f,0.1f,4f,5,0,90,0,0.11f,0.21f,0.27f);
        tp.display();
        tp=new plano(gl,11.81f,4f,-5.4f,4.5f,0.25f,5,0,90,0,0.11f,0.21f,0.27f);
        tp.display();
        
        
          gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,5.94f,1.5f,-5.1f,0.2f,0.5f,1f,0,0,0,0.22f,0.42f,0.54f);
           c1.display();
        gl.glPopMatrix();
        
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,5.94f,2.5f,-5.1f,0.2f,0.5f,1f,0,0,0,0.22f,0.42f,0.54f);
           c1.display();
        gl.glPopMatrix();
        
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,5.94f,3.5f,-5.1f,0.2f,0.5f,1f,0,0,0,0.22f,0.42f,0.54f);
           c1.display();
        gl.glPopMatrix();
        
        
        tp=new plano(gl,3.7f,2.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,3.7f,1.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,3.7f,0.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,6.7f,2.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,6.7f,1.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         tp=new plano(gl,6.7f,0.68f,-10.251f,1f,0.6f,5,0,0,0,0.11f,0.21f,0.27f);
         tp.display();
         
         
         
         
         
         //textura
         tpr=new textPrueba(gl,1.79f,0.5f,-0.5f,15f,20f,5,0,90,0,0);
         tpr.display();
        
         tpr=new textPrueba(gl,1.79f,0.5f,-7.25f,15f,20f,5,0,90,0,2);
         tpr.display();//error
         tpr=new textPrueba(gl,7.2f,2.5f,2.52f,12f,7f,5,0,180,0,1);
        tpr.display();
        
        tpr=new textPrueba(gl,11.5f,1f,-0.49f,6f,7f,5,0,180,0,3);
        tpr.display();
         
         
         
         
                 
        
         
         
         
         
         //interiores3
         //primer piso
         piso1=new Cubo1(gl,7.5f,1.4f,-1f,5,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,8.8f,1.6f,0f,2.2f,0.6f,0.1f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         piso1=new Cubo1(gl,8.7f,1.4f,-0.5f,2.25f,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,9f,1.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,9.5f,1.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,6.8f,1.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,9.9f,1.6f,-0.4f,0.1f,0.6f,0.9f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         
         c1=new Cubo1(gl,7.9f,1.6f,-1.55f,2.2f,0.6f,0.1f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,6.3f,1.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         
         
         //segundo piso
         
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,6.3f,2.4f,-5.1f,0.5f,0.2f,1f,0,0,0,1f,1f,0.4f);
           c1.display();
        gl.glPopMatrix();
         
         piso1=new Cubo1(gl,7.5f,2.4f,-1f,5,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,8.8f,2.6f,0f,2.2f,0.6f,0.1f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         piso1=new Cubo1(gl,8.7f,2.4f,-0.5f,2.25f,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,9f,2.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,9.5f,2.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,6.8f,2.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,9.9f,2.6f,-0.4f,0.1f,0.6f,0.9f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         
         c1=new Cubo1(gl,7.9f,2.6f,-1.55f,2.2f,0.6f,0.1f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,6.3f,2.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         piso1=new Cubo1(gl,5.1f,2.4f,-7.2f,2,0.2f,1.4f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         
         
         //tercer piso
         piso1=new Cubo1(gl,7.5f,3.4f,-1f,5,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,8.8f,3.6f,0f,2.2f,0.6f,0.1f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         piso1=new Cubo1(gl,8.7f,3.4f,-0.5f,2.25f,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,9f,3.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,9.5f,3.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         c1=new Cubo1(gl,6.8f,3.6f,-4.5f,0.1f,0.6f,6f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         c1=new Cubo1(gl,9.9f,3.6f,-0.4f,0.1f,0.6f,0.9f,0,0,0,0.22f,0.42f,0.54f);
         c1.display();
         
         
         c1=new Cubo1(gl,7.9f,3.6f,-1.55f,2.2f,0.6f,0.1f,0,0,0,1f,1f,0.4f);
         c1.display();
         
         piso1=new Cubo1(gl,6.3f,3.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         
         
         
         
         //terraza
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           c1=new Cubo1(gl,6.3f,4.4f,-5.1f,0.5f,0.2f,1f,0,0,0,1f,1f,0.4f);
           c1.display();
        gl.glPopMatrix();
         
         
         
         piso1=new Cubo1(gl,7.5f,4.4f,-1f,5,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         
         
         piso1=new Cubo1(gl,8.7f,4.4f,-0.5f,2.25f,0.2f,1f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
        
         
         piso1=new Cubo1(gl,8.25f,4.4f,-4.4f,3.5f,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display(); 
         
         
         
        
         piso1=new Cubo1(gl,6.3f,4.4f,-4.4f,1,0.2f,6.2f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         piso1=new Cubo1(gl,5.1f,4.4f,-7.2f,2,0.2f,1.4f,0,0,0,1f,1f,0.4f);
         piso1.display();
         
         //ventanas
                 
          v= new ventanas(gl,3.2f,1.1f,-0.489f,0.32f,0.06f,0f,0,0,0,5);
         v.display(); 
         v= new ventanas(gl,3.2f,2f,-0.489f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,3.2f,3f,-0.489f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,3.2f,4f,-0.489f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,3.1f,4f,-3.51f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,3.1f,3f,-3.51f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,3.1f,2f,-3.51f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,3.7f,4f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,3.7f,3f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,3.7f,2f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         
          v= new ventanas(gl,6.68f,4f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         v= new ventanas(gl,6.68f,3f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
          v= new ventanas(gl,6.68f,2f,-10.255f,0.32f,0.07f,0f,0,0,0,5);
         v.display();
         
         
         
          v= new ventanas(gl,5.09f,1.2f,2.52f,0.28f,0.02f,0f,0,0,0,5);
         v.display(); 
           v= new ventanas(gl,6.9f,1.2f,2.52f,0.28f,0.02f,0f,0,0,0,5);
         v.display();
         
         v= new ventanas(gl,3.99f,2f,-4.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
          v= new ventanas(gl,3.99f,3f,-4.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
          v= new ventanas(gl,3.99f,4f,-4.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
         
         
         gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           v= new ventanas(gl,5.84f,4f,-5.1f,0.15f,0.07f,0f,0,90,0,5);
           v.display();
        gl.glPopMatrix();
        
        gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           v= new ventanas(gl,5.84f,3f,-5.1f,0.15f,0.07f,0f,0,90,0,5);
           v.display();
        gl.glPopMatrix();
        
        gl.glPushMatrix();
           gl.glRotatef(20, 0, 1, 0);           
           v= new ventanas(gl,5.84f,2f,-5.1f,0.15f,0.07f,0f,0,90,0,5);
           v.display();
        gl.glPopMatrix();
          
         
         v= new ventanas(gl,4.23f,1.2f,0.7f,0.42f,0.02f,0f,0,90,0,5);
         v.display();
         v= new ventanas(gl,4.23f,2f,0.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
          v= new ventanas(gl,4.23f,3f,0.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
          v= new ventanas(gl,4.23f,4f,0.7f,0.42f,0.07f,0f,0,90,0,5);
         v.display();
         
          v= new ventanas(gl,7.77f,1.2f,1f,0.34f,0.02f,0f,0,-90,0,5);
         v.display();
         v= new ventanas(gl,7.77f,2f,1f,0.34f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,7.77f,3f,1f,0.34f,0.07f,0f,0,90,0,5);
         v.display();
          v= new ventanas(gl,7.77f,4f,1f,0.34f,0.07f,0f,0,90,0,5);
         v.display();
         
         
         v= new ventanas(gl,11.81f,1f,-2.47f,0.48f,0.07f,0f,0,-90,0,5);
         v.display();        
          v= new ventanas(gl,11.81f,2f,-2.47f,0.48f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,3f,-2.47f,0.48f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,4f,-2.47f,0.48f,0.06f,0f,0,-90,0,5);
         v.display();
         
         
          v= new ventanas(gl,11.81f,1f,-5.53f,0.46f,0.07f,0f,0,-90,0,5);
         v.display();        
          v= new ventanas(gl,11.81f,2f,-5.53f,0.46f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,3f,-5.53f,0.46f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,4f,-5.53f,0.46f,0.06f,0f,0,-90,0,5);
         v.display();
         
          v= new ventanas(gl,11.81f,1f,-8.45f,0.44f,0.07f,0f,0,-90,0,5);
         v.display();        
          v= new ventanas(gl,11.81f,2f,-8.45f,0.44f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,3f,-8.45f,0.44f,0.07f,0f,0,-90,0,5);
         v.display();
          v= new ventanas(gl,11.81f,4f,-8.45f,0.44f,0.06f,0f,0,-90,0,5);
         v.display();
         
         
         
         
         
         
         
         
       
         
         
         
         
         
    
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
