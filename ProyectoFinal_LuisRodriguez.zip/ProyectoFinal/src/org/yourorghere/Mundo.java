/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import com.sun.opengl.util.GLUT;
import java.util.ArrayList;
import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author lula
 */
public class Mundo {
    
    GL gl;
    GLUT glut;
    GLU glu;
    Cubo1 c1;    
    Cubo1 piso1;
    float ancho,alto,profundidad;
    float x,y,z;
    float rx,ry,rz;
    plano tp;
    textPrueba tpr;    
    ventanas v;
    cuboText p1;
    cuboText1 p2;
    Escalera esc;
    Meseta m1;
    Edificio1_Lab e1;
    Edificio2_Suelos e2;
    Edificio3_Aulas e3;
    Edificio4_LabIndus e4;
    Edificio5_LabCivil e5;
    Edificio6_nuevo e6;
    monta�a mo;
    Persona per;
    

    public Mundo(GL gl, GLUT glut, GLU glu, float ancho, float alto, float profundidad, float x, float y, float z, float rx, float ry, float rz) {
        this.gl = gl;
        this.glut = glut;
        this.glu = glu;
        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        per= new Persona(gl,2f,2.4f,20f,0.2f,0.2f,0.2f,0f,180f,0f,"parado",2);
        
    }

   
    
    
     public void display(){
        gl.glTranslatef(x, y, z);
        gl.glScalef(ancho, alto, profundidad);
        gl.glRotatef(rx, 1, 0, 0);
        gl.glRotatef(ry, 0, 1, 0);
        gl.glRotatef(rz, 0, 0, 1);
        
        
        gl.glPushMatrix();
        e1= new Edificio1_Lab(gl,glut,glu,1,0.5f,5,0.5f,0.5f,0.5f,0,0,0);
        e1.display();
         gl.glPopMatrix();
         gl.glPushMatrix();         
         e2= new Edificio2_Suelos(gl,glut,glu,1f,1,0.6f,7,1.1f,-8,0,0,0);
         e2.display();
         gl.glPopMatrix();
         gl.glPushMatrix();
         e3= new Edificio3_Aulas(gl,glut,glu,1,1,1,-7,2.6f,-26,0,0,0);
         e3.display();
         gl.glPopMatrix();
         gl.glPushMatrix();
         e4= new Edificio4_LabIndus(gl,glut,glu,1,1,1,1,2.6f,-46,0,0,0);
         e4.display();
         gl.glPopMatrix();
         gl.glPushMatrix();
         e5= new Edificio5_LabCivil(gl,glut,glu,1.5f,1,1,13.5f,2.6f,-38,0,-90,0);
         e5.display();
         gl.glPopMatrix();
         gl.glPushMatrix();
         e6= new Edificio6_nuevo(gl,glut,glu,0.7f,0.8f,0.7f,11.4f,2.5f,-24,0,0,0);
         e6.display();
         gl.glPopMatrix();
         
        p2= new cuboText1(gl,-25.5f,0f,9.7f,270,1f,8,0,0,0,0.4f,0.4f,0.4f);
        p2.display();
        p2= new cuboText1(gl,28.5f,0f,9.7f,270,1f,8,0,90,0,0.4f,0.4f,0.4f);
        //p2.display();
        
         
        p1= new cuboText(gl,-38.5f,0f,20.3f,460,0.6f,460,0,0,0,6);
        p1.display();
         p1= new cuboText(gl,-17.5f,0.25f,1.8f,100,3f,20,0,0,0,4);
        p1.display();
         p1= new cuboText(gl,-17.5f,0.5f,1f,100,3f,20,0,0,0,4);
        p1.display();        
        p1= new cuboText(gl,-17.5f,0.9f,0.5f,100,3f,20,0,0,0,4);
        p1.display();
        
        
        mo= new monta�a(gl,4.6f,0f,2.6f,100,5f,30,0,0,0,1);
        mo.display();
        mo= new monta�a(gl,-6.7f,1.35f,-20f,130,6f,5,0,0,0,1);
        //mo.display();
        mo= new monta�a(gl,-21.7f,3.05f,-43f,100,9f,75,0,0,0,1);
        mo.display();
        
        p1= new cuboText(gl,-21.5f,3.05f,-23.5f,100,0.5f,120,0,0,0,4);
        p1.display();
        p1= new cuboText(gl,9.5f,1.05f,8.5f,100,0.5f,10,0,0,0,4);
        p1.display();
        
        
        esc= new Escalera(gl,glut,glu,3.5f,0.8f,-4,0.2f,1.7f,1f,0,0,0,5);
         esc.display();
         
         esc= new Escalera(gl,glut,glu,-11.5f,1.3f,-5.8f,1.1f,1.7f,0.4f,0,180,0,3);
         esc.display();
         esc= new Escalera(gl,glut,glu,-8.5f,1.9f,-17,0.3f,1f,2f,0,0,0,3);
         esc.display();
         esc= new Escalera(gl,glut,glu,-8.5f,2.3f,-21,0.3f,1.1f,2f,0,0,0,3);
         esc.display();
         esc= new Escalera(gl,glut,glu,-8.5f,2.7f,-25,0.3f,1.1f,2f,0,0,0,3);
         esc.display();
         p2= new cuboText1(gl,-10f,2.93f,-21.5f,95,1f,200,0,0,0,0.3f,0.3f,0.3f);
         p2.display();
         esc= new Escalera(gl,glut,glu,8.2f,2.7f,-27,0.11f,1.1f,1.5f,0,0,0,2);
         esc.display();
         
         esc= new Escalera(gl,glut,glu,4f,2.7f,-22f,1.1f,1.1f,0.15f,0,180,0,3);
         esc.display();
         
         esc= new Escalera(gl,glut,glu,24f,2.7f,-22f,1.1f,1.1f,0.15f,0,0,0,5);
         esc.display();
         p2= new cuboText1(gl,10.5f,2.8f,-21.5f,50,0.2f,10,0,0,0,0.3f,0.3f,0.3f);
        p2.display();
         
          p2= new cuboText1(gl,-17.5f,1.263f,-3.5f,210,1f,100,0,0,0,0.3f,0.3f,0.3f);
        p2.display();
        
         p2= new cuboText1(gl,17.5f,1.263f,-13.5f,210,1f,100,0,0,0,0.1f,0.1f,0.1f);
        //p2.display();
        
        
         
         
        
         
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
