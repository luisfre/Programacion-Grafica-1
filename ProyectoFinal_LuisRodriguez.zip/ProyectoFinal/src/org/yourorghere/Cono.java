package org.yourorghere;

import com.sun.opengl.util.GLUT;
import javax.media.opengl.GL;

public class Cono {

    GL gl;
    GLUT glut;
    double B, A;
    int sl, st;
    float r, g, b;

    public Cono(GL gl, GLUT glut, double B, double A, int sl, int st, float r, float g, float b) {
        this.gl = gl;
        this.glut = glut;
        this.B = B;
        this.A = A;
        this.sl = sl;
        this.st = st;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public void DrawCono(float angle, float PX, float PY, float PZ) {
        gl.glPushMatrix();
        gl.glTranslatef(PX, PY, PZ);
        gl.glRotated(angle, 1, 0, 0);
        gl.glColor3f(1,1,1);
        glut.glutWireCone(B,A,sl,st);
        gl.glColor3f(r, g, b);
        glut.glutSolidCone(B, A, sl, st);
        gl.glPopMatrix();

    }
}
