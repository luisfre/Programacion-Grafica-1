/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author Luis Rodriguez
 */
public class ventanas {

    GL gl;
    float x,y,z,ancho,alto,prof,rx,ry,rz;
    int tipo;
    vidrio v;
    plano p1;

    public ventanas(GL gl, float x, float y, float z, float ancho, float alto, float prof, float rx, float ry, float rz,int tipo) {
        this.gl = gl;
        this.x = x;
        this.y = y;
        this.z = z;
        this.ancho = ancho;
        this.alto = alto;
        this.prof = prof;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
        this.tipo = tipo;
        
    }

    public void display(){
        
         gl.glPushMatrix();
           
        
         gl.glTranslatef(x, y, z);        
         gl.glRotatef(rx, 1, 0, 0);
         gl.glRotatef(ry, 0, 1, 0);
         gl.glRotatef(rz, 0, 0, 1);
         gl.glScalef(ancho, alto, prof);
         
         //edificio 1
         if (tipo==0) {
             
         v=new vidrio(gl,0.1f,-1.5f,6f,3f,3f,5,0,0,0,0.11f,0.21f,0.27f,0);
         v.display();
             for (float i = -2.7f; i <= 3f; i=i+0.2f) {
                p1=new plano(gl,i,-1.5f,6.04f,0.01f,3f,0,0,0,0,1f,1f,0.4f);
                p1.display(); 
             }
         p1=new plano(gl,0.1f,2.8f,6.02f,3f,0.3f,5,0,0,0,1f,1f,0.4f);
         p1.display();
         p1=new plano(gl,0.1f,-4.5f,6f,3f,3f,5,0,0,0,1f,1f,1f);
         p1.display();    
         
        }else if (tipo==1) {
            
             for (int i = 1; i < 15; i=i+6) {
                 
                 gl.glPushMatrix();
                  gl.glTranslatef(i, 0, 0);  
                 
                     p1=new plano(gl,0.1f,2.9f,6f,3f,0.1f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,0.1f,2.2f,6f,3f,0.1f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,0.1f,1.4f,6f,3f,0.1f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,0.1f,-0.9f,6f,3f,0.1f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,-2.9f,-9.6f,6f,0.05f,6.35f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,3.15f,-9.6f,6f,0.05f,6.35f,5,0,0,0,1f,1f,0.4f);
                     p1.display();
                     p1=new plano(gl,0.1f,0f,6f,3f,1.5f,5,0,0,0,0.6f,0.6f,0.3f);
                     p1.display();


                    p1=new plano(gl,0.1f,-5.75f,6f,3f,2.5f,5,0,0,0,0.9f,0.9f,0.9f);
                    p1.display();
                    p1=new plano(gl,0.1f,-3.5f,6f,3f,2.5f,5,0,0,0,1f,1f,1f);
                    p1.display();

                 
                 
                 
                 gl.glPopMatrix();
                 
                 
             }
           
        }else if (tipo==2) {
            
             for (float i = -2.7f; i <=3f; i=i+0.2f) {
                p1=new plano(gl,i,0.5f,6.04f,0.01f,2f,0,0,0,0,1f,1f,0.4f);
                p1.display(); 
             }
         p1=new plano(gl,0.1f,-1.5f,6f,3f,3f,5,0,0,0,0.8f,0.8f,0.8f);
         p1.display();
         p1=new plano(gl,0.1f,-8.5f,6f,3f,5f,5,0,0,0,0.7f,0.7f,0.7f);
         p1.display();
         p1=new plano(gl,0.1f,2.8f,6.02f,3f,0.3f,5,0,0,0,1f,1f,1f);
         p1.display();
         p1=new plano(gl,0.1f,0f,6.02f,3f,0.3f,5,0,0,0,1f,1f,1f);
         p1.display();
         p1=new plano(gl,0.1f,-2.8f,6.02f,3f,0.3f,5,0,0,0,1f,1f,1f);
         p1.display();
         
            
        }else if (tipo==3) {
                         
          p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,0f,0f,0f);
          p1.display();
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,0f,0f,0f);
          p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,0f,0f,0f);
          p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,0f,0f,0f);
          p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,0f,0f,0f);
          p1.display();   
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,0f,0f,0f);
          p1.display();
           p1=new plano(gl,0.09f,0f,6f,2.96f,0.2f,0,0,0,0,0f,0f,0f);
          p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,0f,0f,0f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,1);
         v.display();
    
        }
         //edificio 2
        else if (tipo==4) {
            
           p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();   
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
           p1=new plano(gl,0.09f,0f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,2);
         v.display();
        }else if (tipo==5) {
            
           p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          //medios vertical
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          //medio horizontal
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
           p1=new plano(gl,0.09f,0f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,3);
         v.display();
        }else if (tipo==6) {
            
           p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          //medios vertical
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();   
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
           p1=new plano(gl,0.09f,0f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          //p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,4);
         v.display();
        }else if (tipo==7) {
            
           p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          //medios vertical
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();   
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
           p1=new plano(gl,0.09f,1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,4);
         v.display();
        }else if (tipo==8) {
            
           p1=new plano(gl,-2.9f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();
          //medios vertical
          p1=new plano(gl,-1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,0f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display(); 
           p1=new plano(gl,1.5f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          //p1.display();
          p1=new plano(gl,3f,-11.5f,6f,0.1f,8f,0,0,0,0,1f,1f,1f);
          p1.display();   
          p1=new plano(gl,0.09f,-3.7f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display();
           p1=new plano(gl,0.09f,0f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          //p1.display();
          
          p1=new plano(gl,0.09f,4.1f,6f,2.96f,0.2f,0,0,0,0,1f,1f,1f);
          p1.display(); 
         v=new vidrio(gl,0.1f,12.5f,6f,3f,8f,5,0,0,180,1f,1f,1f,5);
         v.display();
        }
         
        

          gl.glPopMatrix();
        
        
        
    }
    


    
    
}
